<!--
The video walk through is [here](FIX-ME).
-->

Instructions:

1. Upload your video walk through to Google Drive.
2. Under sharing, allow anyone with the link to view the video.
3. Place a link to the video above, and uncomment those lines.
4. `git commit -a`, `git push`.
5. Using incognito mode on your browser, verify that the video is indeed accessible to anybody with the link.

Remember that **your video duration is limited to an maximum of 5 minutes.**   
