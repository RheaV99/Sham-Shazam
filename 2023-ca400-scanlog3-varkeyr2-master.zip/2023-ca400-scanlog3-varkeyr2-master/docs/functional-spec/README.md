Place your functional specification in this directory.

A general template for the functional specification (in MS Word format) is located in this directory. 

The first page of your functional specification should contain at least:

- your names,
- your project title,
- the type of document (e.g. *Functional Specification*)
- your student IDs, and
- the date you finished working on the document.

**When it comes to actual submission, you should create a PDF copy of your final version and store it in this directory also.**

*Do not place any other files in this directory.*