import React, { useState, useEffect, Component,  } from 'react';
import findSong from '../components/songdetails';
import '../style.css';
import '../play.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlay, faStop } from '@fortawesome/free-solid-svg-icons'
import MicRecorder from 'mic-recorder-to-mp3';


const Play = () => {
  const [songData, setSongData] = useState({});
  const [blobURL, setBlobURL] = useState({}); //(for testing)
  const [isRecording, setIsRecording] = useState(false);

  const recorder = new MicRecorder({
    bitRate: 128
  });
   
  const start = () => {
    // Start recording.
    recorder.start().then(() => {
    }).catch((e) => {
      console.error(e);
    });
  }
   
  const stop = async () => {
    // Stop recording, save audio to file and pass to API
    recorder.stop().getMp3().then(async ([buffer, blob]) => {
      const audioFile = new File(buffer, 'song.mp3', {
        type: blob.type,
        lastModified: Date.now()
      })
      console.log(audioFile)
      const blobURL = URL.createObjectURL(blob)
      setBlobURL(blobURL)
      
      // Make call to API to get song data
      const data = await findSong(audioFile);
      setSongData(data.data);
      console.log(data.data)
    }).catch((e) => {
      console.error(e);
    });
  }

  function logout(){
      localStorage.clear();
      window.location.href = 'http://localhost:3000/';
  }
  function History(){

    window.location.href = 'http://localhost:3000/songHistory';
}

  return (
    <div>

     
        <button className='logoutbtn'onClick={logout}>Logout</button>
        <button className='SHistory'onClick={History}>Song History</button>
        
      
      <div className="recordBtn">
      <button className="Startbtn" onClick={start}>
          <FontAwesomeIcon icon={faPlay} size="7x" />
         
          </button>
        <button className="Stopbtn" onClick={stop}>
        <FontAwesomeIcon icon={faStop} size="7x" />
          
        </button>
          
          {songData.result && (
        <div>
          <p>Song Title: {songData.result.title}</p>
          <p>Artist: {songData.result.artist}</p>
        </div>
      )}
      </div>
    </div>
  );
}

export default Play;
