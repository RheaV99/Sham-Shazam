import './style.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { useAuthContext } from './hooks/useAuthContext';
import React, { useState } from 'react'
import AudioReactRecorder, { RecordState } from 'audio-react-recorder'




//Pages
import Home from './pages/Home'
import Play from './pages/play'

import Navbar from './components/nav'

// Audio function
/*function Audio() {
  const [recordstate, setrecordstate] = useState("NONE");
  const [blobURL, setblobURL] = useState("");

  const start = () => {
    console.log(recordstate);
    console.log("start");
    setrecordstate(RecordState.START);
  };

  const stop = () => {
    console.log("stop");
    setrecordstate(RecordState.STOP);
  };

  const onStop = (audioData) => {
    console.log("audio data: " + audioData.url);
    setblobURL(audioData.url);
    console.log(blobURL);
  };
  return (
    <div>
      <AudioReactRecorder state={recordstate} onStop={onStop} />
      <button onClick={start}>Start</button>
      <button onClick={stop}>Stop</button>
    </div>
  );
}*/


function App() {
  const { user } = useAuthContext()

  return (
    <div className='App'>
      <BrowserRouter>
        <Navbar />
        <div className='pages'>
          <Routes>
            <Route 
              path="/"
              element={<Home />}
            />
            <Route 
              path="/play" 
              element={<Play />} 
            />
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
