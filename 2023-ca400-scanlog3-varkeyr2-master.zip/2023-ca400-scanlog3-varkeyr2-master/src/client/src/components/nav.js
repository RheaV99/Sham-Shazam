import { Link } from 'react-router-dom'
import { useAuthContext } from '../hooks/useAuthContext'

const Navbar = () => {
    
  const { user } = useAuthContext()

  return (
    <header>
      <div className="container">
        <nav>
            {user && (
                <div>
                <span>{user.email}</span>
                </div>
            )}
        </nav>
      </div>
    </header>
  )
}

export default Navbar