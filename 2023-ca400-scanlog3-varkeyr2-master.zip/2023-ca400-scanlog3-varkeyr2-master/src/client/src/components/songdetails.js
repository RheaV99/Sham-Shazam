import React from "react";
import axios from 'axios';

const findSong = async (audio) => {
    var data = {
        'file': audio,
        'return': 'apple_music,spotify',
        'api_token': '8de7a4b9eb4b165ab7235771c3fc318c'
    }

    const response = await axios({
        method: 'post',
        url: 'https://api.audd.io/',
        data: data,
        headers: { 'Content-Type': 'multipart/form-data' },
    })

    return response;
}

export default findSong;